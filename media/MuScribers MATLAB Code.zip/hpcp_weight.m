function w=hpcp_weight(n,fi,f_ref)
% n ranges from 1 to 12, representing a certain note in an octave
% fi is one of the peak frequencies in FFT. 
% The return value w represents the correlation between the peak frequency 
% and the note represented by n
fn=f_ref*power(2,n/12);% f_ref=440Hz, can be adjusted, doesn't really matter
d=12*log2(fi/fn)-12*round(log2(fi/fn));
l=0.8;% weighting window length, can be adjusted
if abs(d)<=0.5*l% if close enough
    w=(cos(pi*d/l))^2;% cos^2 weighting function
else w=0;
end