function octave=findoctave(n,fi,f_ref)
% n ranges from 1 to 12, representing a certain note in an octave
% fi is one of the peak frequencies in FFT. 
% The return value octave represents the octave note n is in
fn=f_ref*power(2,n/12)/2^4;% N0 frequency, N = C/C#/D/...
result=round(log2(fi/fn));% same way in hpcp_weight()
if n>2 % C or above
    octave=result+1;
else octave=result;
end