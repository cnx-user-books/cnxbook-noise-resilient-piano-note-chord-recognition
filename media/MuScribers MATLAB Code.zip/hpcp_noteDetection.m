%%%hpcp_noteDetection demonstrates the flow of note detection using HPCP 
%%%Comment/Uncomment according to need. It shows how to use the program
%%%with any song

%%Read the audio file
[data, fs] = audioread('ChordProgression.wav');

%%Create strings that represent the correct result; they are the
%%notes/chords in the input audio file

% correct_ba_synth=['C C G G A A A A G F F E E D D C G G G F F F E E E D G G G F F F E E E D C C G G A A G F F E E D D C'];
correct_ba_synth=['CCGGAAAAGFFEEDDCGGGFFFEEEDGGGFFFEEEDCCGGAAGFFEEDDC'];
%correct_ba_real=['C C G G A A G F F E E D D C G G G F F F E E E D G G G F F F E E E D C C G G A A A A G F F E E D D C'];
correct_ba_real=['CCGGAAGFFEEDDCGGGFFFEEEDGGGFFFEEEDCCGGAAAAGFFEEDDC'];
% correct_hcb=['E D C E D C C C C C D D D D E D C'];
correct_hcb=['EDCEDCCCCCDDDDEDC'];
correct_badromance = ['CDECACFEFEDBGBCDECAEFEDCAE'];
correct_odesimpler = ['C E G | E | F | G | G | F | E | D | C | C | D | E | E | D | D B | E C G | E | F | G | G | F | E | D | C | C | D | E | D | C | C G'];
%correct_starspangled = ['G | E | C | E | G | C | E5 | D5 | C5 | E | F# | G | G | G | E5 | D5 | C5 | B5 | A5 | B5 | C5 | C5 | G | E | C'];
correct_starspangled = ['GECEGCEDCENGGGEDCBABCCGEC'];
correct_odesimpler2 = ['CEGEFGGFEDCCDEEDBDCEGEFGGFEDCCDEDCCG'];
% correct_odesimpler2 = ['CEGEFGGFEDCCDEEDDBECGEFGGFEDCCDEDCCG'];

correct_chordp=['CEGBFGCEGACFCEG'];

%%Get the first channel
data1 = data(:,1);

%%Get the note onsets
[bpm, notes, note_times,onset] = noteDivider(data1, fs);

%%Dictionary that maps HPCP indices to notes. Notice Sharps are turned into
%%single letter notes
%dict=['A#','B ','C ','C#','D ','D#','E ','F ','F#','G ','G#','A '];
dict=['K ','B ','C ','L ','D ','M ','E ','F ','N ','G ','O ','A '];
%%dict2 is a mapping from octave number to string version
dict2=['1 ','2 ','3 ','4 ','5 ','6 ','7 ','8 '];

%%noteRecognizer builds HPCP vectors of each note and returns the
%%frequency content as a matrix where each row represents a note
[note_freqs]=noteRecognizer(data1,onset,fs);

%%Dislay the result!
out=[];out2=[];
[m, n]=size(note_freqs);
for i=1:m/2,
    tmp=[];
    for j=1:n,
        
        if note_freqs(2*i-1,j)~=-1
            tmp=[tmp dict(note_freqs(2*i-1,j)*2-1)];
            tmp=[tmp dict(note_freqs(2*i-1,j)*2)];
            out2=[out2 dict2(note_freqs(2*i,j)*2-1)];
            out2=[out2 dict2(note_freqs(2*i,j)*2)];
        else
            break;
        end
    end
    tmp=sort(tmp);
    out=[out tmp];
    out=[out ' | '];
    out2=[out2 ' | '];
end

notes=out
octave=out2
correct_chordp
accuracy=[];
no_spaces=[];

%Calculate accuracy
for i=1:length(out),
    if(out(i)~=' ' && out(i)~='|')
        no_spaces=[no_spaces out(i)];
    end
end
no_spaces
s=length(correct_chordp);
accuracy=[accuracy 100*(s-edit_distance_levenshtein(no_spaces,correct_chordp))/s];

accuracy