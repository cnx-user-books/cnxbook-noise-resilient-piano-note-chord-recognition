%%%compress is a gain compression function that takes in a signal, flattens
%%%large peaks and expands other peaks using the formula:
%%% y=1-(1-|x|)^param * sign(x)

function out=compress(samples,param)
out=[];
for i=1:length(samples),
        if samples(i) < 0
            sign = -1;
        else
            sign=1;
        end
        norm = abs(samples(i)); 
        norm = 1.0 - (1.0 - norm)^param;
        out(i) = norm * sign;
end

end