%%Similar to hpcp_noteDetection, this program adds additive white gaussian
%%noise to create SNR between -10dB to 15dB. Runs the trial ten times and
%%plots the result
[data, fs] = audioread('BaaBaaBlackSheep.wav');

correct_ba=['CCGGAAGFFEEDDCGGGFFFEEEDGGGFFFEEEDCCGGAAAAGFFEEDDC'];
correct_hcb=['EDCEDCCCCCDDDDEDC'];
correct_badromance = ['CDECACFEFEDBGBCDACEEFEDACE'];
% correct_odesimpler = ['E C G | E | F | G | G | F | E | D | C | C | D | E | E | D | D B | E C G | E | F | G | G | F | E | D | C | C | D | E | D | C | C G'];
% correct_starspangled = ['G | E | C | E | G | C | E5 | D5 | C5 | E | F# | G | G | G | E5 | D5 | C5 | B5 | A5 | B5 | C5 | C5 | G | E | C'];


total=[-10];
for all=1:10,
accuracy=[];
for it=-10:15,
    it
    data1 = data(:,1);
data1=awgn(data1,it,'measured');
data1=data1./max(data1);
[bpm, notes, note_times,onset] = noteDivider(data1, fs);
% note_times=timeout(data1,fs);
dict=['K ','B ','C ','L ','D ','M ','E ','F ','N ','G ','O ','A '];
dict2=['1 ','2 ','3 ','4 ','5 ','6 ','7 ','8 '];
[note_freqs]=noteRecognizer2(data1,onset,fs);
out=[];out2=[];
[m n]=size(note_freqs);
for i=1:m/2,
    tmp=[];
    for j=1:n,
        
        if note_freqs(2*i-1,j)~=-1
            tmp=[tmp dict(note_freqs(2*i-1,j)*2-1)];
            tmp=[tmp dict(note_freqs(2*i-1,j)*2)];
%             out2=[out2 dict2(note_freqs(2*i,j)*2-1)];
%             out2=[out2 dict2(note_freqs(2*i,j)*2)];
        else break;
        end
    end
    if(length(tmp)>4)
        tmp=sort(tmp);
    end
 out=[out tmp];
%     out2=[out2 ' | '];
end
no_spaces=[];
for i=1:length(out),
    if(out(i)~=' ')
        no_spaces=[no_spaces out(i)];
    end
end
out
% correct_hcb
correct_ba
s=length(correct_ba);
accuracy=[accuracy max(100*(s-edit_distance_levenshtein(no_spaces,correct_ba))/s,0)];

end

accuracy
if(total(1)==-10)
    total=accuracy;
else
    total=total+accuracy;
end



end
total