%Input: notes_time, vector of number of samples for each note 

function [note_freqs]=noteRecognizer(x,onset,fs)
    
    n=1;
    note_freqs=[];
    
    
    for i=1:length(onset),
        
        if(i==length(onset))
            a=x(round(onset(i)):end);
        else
            if(onset(i)<=0)
                onset(i)=1;
            end      
            a=x(onset(i):onset(i+1));
        end
        %a=x(note_times(i):note_times(i+1)-1);
        %a=a(round(0.15*length(a)):round(length(a)*0.85));
        if(length(a)<10)
            onset
            continue;
        end
        A=abs(fft(a));
        A=A./max(A);
        %Filter out unnecessary frequencies (less than 50Hz and greater than
    %4000 Hz)
        A=A(1:round(5500*(length(A)/fs)));
       
        [pks,locs]=findpeaks(A,'sortstr','none','minpeakheight',0.1); % Find peaks 
%         figure;
%         plot((1:length(A))*5500/length(A),A);
        [hpcp, octave]=hpcp_compute(locs(1:end).*fs/length(a),pks(1:end));
        %note_freqs(i)=locs(1)*fs/note_times(i);            
        [Y,I]=sort(hpcp,'descend');
%         figure;
%         bar(hpcp)
        %hpcp
        %octave
        
        thresh = min(mean(hpcp),0.4);

        for j=1:5 % at most 5-note chord
            if Y(j)>thresh
                note_freqs(2*i-1,j)=I(j);
                note_freqs(2*i,j)=octave(I(j));
            elseif Y(j)<thresh&&Y(j-1)>thresh
                for k=j:5
                    note_freqs(2*i-1,k)=-1;
                    note_freqs(2*i,k)=-1;
                end
                break;
            end
        end
       
    end   
    

end