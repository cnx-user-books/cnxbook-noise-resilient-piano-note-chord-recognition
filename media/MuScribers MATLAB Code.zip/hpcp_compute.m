function [hpcp, octave]=hpcp_compute(f,a)
% f: vector containing peak frequencies in FFT
% a: vector containing corresponding peak amplitude in FFT
% vector f and a should have the same length and f should be ascending
hpcp=zeros(1,12);
octave=zeros(1,12);
len=length(f);
f_ref=440;
for n=1:12% iterate for different notes
    flag = 0;
    for i=1:len% iterate for all peaks
        hpcp(n)=hpcp(n)+hpcp_weight(n,f(i),f_ref)*a(i)^2;
        if flag==0&&hpcp_weight(n,f(i),f_ref)~=0% first peak that returns a positive weight
            octave(n)=findoctave(n,f(i),f_ref);% take that as octave
            flag=1;
        end
    end
end
for n=1:12
    if octave(n)>8% if octave is too big, consider that as invalid
        octave(n)=0;
        hpcp(n)=0;
    end
end
for n=1:12
     hpcp(n)=hpcp(n)/max(hpcp);% normalize
end