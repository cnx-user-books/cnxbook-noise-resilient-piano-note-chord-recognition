%Say bpm has to be between 100 and 200;
%notes is the length of each note in the sequence
%4 corresponds to a whole note, 2 to a half note, 1 to a quarter note, etc.
%notetimes is the number of samples in length of each note.

function [bpm, notes, notetimes,onset] = noteDivider(data, fs)
figure();


plot(data,'b');
hold on;
datap=data;
data=abs(compress(data,2));
N = length(data);
tol = .15;      %Tolerance for variation in note length
boxcar = ones(1,round(fs*.1));
boxcar = conv(boxcar, boxcar);
boxcar = conv(boxcar, boxcar);
smoothed = conv(boxcar, data);
smoothed=smoothed./max(smoothed);
% %Use hanning
% w=hann(fs*0.04);
% smoothed_2=conv(datap,w);
% smoothed_2=smoothed_2./max(smoothed_2);
% plot(smoothed_2,'k');
 plot(smoothed,'r');
 thresh=mean(smoothed);
[~, peaks] = findpeaks(smoothed,'minpeakheight',thresh);
stem(peaks-fs*(thresh),ones(length(peaks)),'k');

hold on;
%The length of each 
notetimes = zeros(length(peaks), 1);
thresh
for i = 1:length(peaks)
    if (i == length(peaks))
        notetimes(i) = max(N+peaks(1) - peaks(i),0);
    else
        notetimes(i) = max(peaks(i+1) - peaks(i),0);
    end
end
onset=max(peaks-fs*(thresh),0);
tmp=onset;
for i=2:length(onset)-1,
if(onset(i)==0.0)
    tmp=onset(i+1:end);
end
end

onset=tmp;
%Identify tempo.
%Find the shortest interval to make our smallest note.
beat = 1;
smallest = min(notetimes);
smallest = mean(notetimes(notetimes < smallest*(1+tol)));
while(smallest/beat/fs < .3)
    beat = .5*beat;
end

bpm = beat*fs/smallest*60;

%Construct notes
notes = .5*round(2*beat*notetimes/smallest);

%%Plot results of note onset detection


 title('The smoothed signal');
%  legend('Smoothed signal');
 legend('Input Audio File','The Smoothed Signal','Note Onsets');
 %stem(cumsum(notetimes'),ones(length(notetimes)),'b');
 
% legend('Note onsets based on smoothed');
 
 close all;
 

return